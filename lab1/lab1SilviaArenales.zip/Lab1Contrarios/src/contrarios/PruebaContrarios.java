package contrarios;

import java.util.Arrays;
import java.util.Collections;

import auxiliares.ArrayCreator;
import auxiliares.Stopwatch;

public class PruebaContrarios {
	
	public static void main(String[] args) { 	
		
		Contrarios c = new Contrarios();
		int[] a;//= {-7,-4,-1,0,1,2,3,7};
		Stopwatch timer;		
		int N=250;
		while(true) {
			a= ArrayCreator.createArrayNoRepOrdered(N); //Crea un array de N elementos ordenados ascendentemente
			
			timer = new Stopwatch(); //Pone en marcha el cron�metro
			c.cuantosContrarios2(a); //Llama a cuantosContrarios
			System.out.println(N+":"+timer.elapsedTime());	//Imprime el tiempo transcurrido	
			N=N*2; //Duplica el tama�o del array
		}
		
		
		
		
	}
    


}
