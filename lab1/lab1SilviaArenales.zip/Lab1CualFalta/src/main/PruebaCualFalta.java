package main;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class PruebaCualFalta {

	public static void main(String[] args) throws FileNotFoundException {
		
		CualFalta cf = new CualFalta();
		Scanner sc = new Scanner(new File("src/ficheros/cualfalta.txt"));
		String linea;
		String[] nums;
		int[] arr;
		while(sc.hasNextLine()) {
			linea = sc.nextLine();			
			nums = linea.split("\\s+");
			arr = new int[nums.length];
			for(int i=0; i<nums.length; i++) {
				arr[i] = Integer.parseInt(nums[i]);
			}
			System.out.println("En el array ["+linea+"] el n� que falta es "+cf.cualFalta1(arr));
		}
		sc.close();		

	}

}
