package main; 

public class CualFalta {

	
	public int cualFalta1(int arr[]) {
		int i = 0;
		while(i<arr.length) {
			if(arr[i]!=i) return i;
			i++;
		}
		return arr.length;
	}
	

	
	public int cualFalta2(int arr[]) {
		
		int ini = 0;
		int fin = arr.length-1;
		int a=0;
		int i=0;
		boolean desordenado=false;
		//TO DO
		while(desordenado==false && i<fin ) {
			if(a!=arr[i]) { 
				desordenado=true;
				return i;
			}
		}
			
		return -1; //Nunca va a llegar aqu�
		//FIN TO DO
	}
	

	


}
